// SPDX-License-Identifier: GPL-3.0-only
/*
 *  Prism Launcher - Minecraft Launcher
 *  Copyright (C) 2026 TheKodeToad <TheKodeToad@proton.me>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#pragma once

template <auto TDeleteFunc>
struct FuncDeleter {
    void operator()(auto* t) { TDeleteFunc(t); }
};

template <typename T, auto TDeleteFunc>
class Handle : public std::unique_ptr<T, FuncDeleter<TDeleteFunc>> {
   public:
    using std::unique_ptr<T, FuncDeleter<TDeleteFunc>>::unique_ptr;

    // NOLINTNEXTLINE(hicpp-explicit-conversions)
    operator T*() const { return this->get(); }
};
