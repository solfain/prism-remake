/* Copyright 2015-2021 MultiMC Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "BaseEntity.h"
#include <expected>
#include <utility>

#include "FileSystem.h"
#include "Json.h"
#include "Result.h"
#include "modplatform/helpers/HashUtils.h"
#include "net/ApiRequest.h"
#include "net/ChecksumValidator.h"
#include "net/HttpMetaCache.h"
#include "net/Mode.h"
#include "net/NetJob.h"

#include "Application.h"
#include "BuildConfig.h"
#include "settings/SettingsObject.h"
#include "tasks/Task.h"

namespace {
class ParsingValidator : public Net::Validator {
   public: /* con/des */
    explicit ParsingValidator(Meta::BaseEntity* entity) : m_entity(entity) {};
    ~ParsingValidator() override = default;

   public: /* methods */
    void init() override { m_data.clear(); }
    void write(const QByteArray& data) override { this->m_data.append(data); }
    void abort() override { m_data.clear(); }
    Result<> validate() override
    {
        auto fname = m_entity->localFilename();
        return Json::requireObject(m_data, fname).and_then([this](const auto& v) { return m_entity->parse(v); });
    }

   private: /* data */
    QByteArray m_data;
    Meta::BaseEntity* m_entity;
};
}  // namespace
namespace Meta {

QUrl BaseEntity::url() const
{
    auto* s = APPLICATION->settings();
    QString metaOverride = s->get("MetaURLOverride").toString();
    if (metaOverride.isEmpty()) {
        return QUrl(BuildConfig.META_URL).resolved(localFilename());
    }
    return QUrl(metaOverride).resolved(localFilename());
}

Task::Ptr BaseEntity::loadTask(Net::Mode loadType, bool forceReload)
{
    if (m_task && m_task->isRunning()) {
        return m_task;
    }
    m_task.reset(new BaseEntityLoadTask(this, loadType, forceReload));
    return m_task;
}

bool BaseEntity::isLoaded() const
{
    // consider it loaded only if the main hash is either empty and was remote loadded or the hashes match and was loaded
    return m_sha256.isEmpty() ? m_loadStatus == LoadStatus::Remote : m_loadStatus != LoadStatus::NotLoaded && m_sha256 == m_fileSha256;
}

void BaseEntity::setSha256(QString sha256)
{
    m_sha256 = std::move(sha256);
}

BaseEntity::LoadStatus BaseEntity::status() const
{
    return m_loadStatus;
}

BaseEntityLoadTask::BaseEntityLoadTask(BaseEntity* parent, Net::Mode mode, bool forceReload)
    : m_entity(parent), m_mode(mode), m_forceReload(forceReload)
{}

void BaseEntityLoadTask::executeTask()
{
    const QString fname = QDir("meta").absoluteFilePath(m_entity->localFilename());
    auto hashMatches = false;
    // the file exists on disk try to load it
    if (QFile::exists(fname)) {
        auto parse = [this, &hashMatches, fname] -> Result<> {
            QByteArray fileData;
            // read local file if nothing is loaded yet
            if (m_entity->m_loadStatus == BaseEntity::LoadStatus::NotLoaded || m_entity->m_fileSha256.isEmpty()) {
                setStatus(tr("Loading local file"));

                TRY_INTO(fileData, FS::read(fname))

                m_entity->m_fileSha256 = Hashing::hash(fileData, Hashing::Algorithm::Sha256);
            }

            // on online the hash needs to match
            const auto& expected = m_entity->m_sha256;
            const auto& actual = m_entity->m_fileSha256;
            hashMatches = expected == actual;
            if (m_mode == Net::Mode::Online && !m_entity->m_sha256.isEmpty() && !hashMatches) {
                return std::unexpected(QString("Checksum mismatch, expected sha256: %1, got: %2").arg(expected, actual));
            }

            // load local file
            if (m_entity->m_loadStatus == BaseEntity::LoadStatus::NotLoaded) {
                TRY(Json::requireObject(fileData, fname).and_then([this](const auto& v) { return m_entity->parse(v); }));
                m_entity->m_loadStatus = BaseEntity::LoadStatus::Local;
            }
            return {};
        };
        auto res = parse();
        if (!res) {
            qCritical() << QString("Unable to parse file %1: %2").arg(fname, res.error());
            // just make sure it's gone and we never consider it again.
            FS::deletePath(fname);
            m_entity->m_loadStatus = BaseEntity::LoadStatus::NotLoaded;
        }
    }
    // if we need remote update, run the update task
    auto wasLoadedOffline = m_entity->m_loadStatus != BaseEntity::LoadStatus::NotLoaded && m_mode == Net::Mode::Offline;
    // if has is not present allways fetch from remote(e.g. the main index file), else only fetch if hash doesn't match
    auto wasLoadedRemote = m_entity->m_sha256.isEmpty() ? m_entity->m_loadStatus == BaseEntity::LoadStatus::Remote : hashMatches;
    if (wasLoadedOffline || (wasLoadedRemote && !m_forceReload)) {
        emitSucceeded();
        return;
    }
    m_task.reset(new NetJob(QObject::tr("Download of meta file %1").arg(m_entity->localFilename()), APPLICATION->network()));
    auto url = m_entity->url();
    auto entry = APPLICATION->metacache()->resolveEntry("meta", m_entity->localFilename());
    if (m_forceReload) {
        // clear validators so manual refreshes fetch a fresh body
        entry->setETag({});
        entry->setRemoteChangedTimestamp({});
    }
    entry->setStale(true);
    auto dl = Net::ApiRequest::makeCached(url, entry);
    /*
     * The validator parses the file and loads it into the object.
     * If that fails, the file is not written to storage.
     */
    if (!m_entity->m_sha256.isEmpty()) {
        dl->addValidator(new Net::ChecksumValidator(QCryptographicHash::Algorithm::Sha256, m_entity->m_sha256));
    }
    dl->addValidator(new ParsingValidator(m_entity));
    m_task->addNetAction(dl);
    m_task->setAskRetry(false);
    connect(m_task.get(), &Task::failed, this, &BaseEntityLoadTask::emitFailed);
    connect(m_task.get(), &Task::succeeded, this, [this]() {
        m_entity->m_loadStatus = BaseEntity::LoadStatus::Remote;
        m_entity->m_fileSha256 = m_entity->m_sha256;
        emitSucceeded();
    });

    connect(m_task.get(), &Task::progress, this, &Task::setProgress);
    connect(m_task.get(), &Task::stepProgress, this, &BaseEntityLoadTask::propagateStepProgress);
    connect(m_task.get(), &Task::status, this, &Task::setStatus);
    connect(m_task.get(), &Task::details, this, &Task::setDetails);

    m_task->start();
}

bool BaseEntityLoadTask::canAbort() const
{
    return m_task ? m_task->canAbort() : false;
}

bool BaseEntityLoadTask::abort()
{
    if (m_task) {
        Task::abort();
        return m_task->abort();
    }
    return Task::abort();
}

}  // namespace Meta
