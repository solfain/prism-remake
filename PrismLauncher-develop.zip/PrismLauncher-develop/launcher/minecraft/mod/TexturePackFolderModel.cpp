// SPDX-License-Identifier: GPL-3.0-only
/*
 *  Prism Launcher - Minecraft Launcher
 *  Copyright (c) 2022 flowln <flowlnlnln@gmail.com>
 *  Copyright (C) 2022 Sefa Eyeoglu <contact@scrumplex.net>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * This file incorporates work covered by the following copyright and
 * permission notice:
 *
 *      Copyright 2013-2021 MultiMC Contributors
 *
 *      Licensed under the Apache License, Version 2.0 (the "License");
 *      you may not use this file except in compliance with the License.
 *      You may obtain a copy of the License at
 *
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 *      Unless required by applicable law or agreed to in writing, software
 *      distributed under the License is distributed on an "AS IS" BASIS,
 *      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *      See the License for the specific language governing permissions and
 *      limitations under the License.
 */
#include "TexturePackFolderModel.h"

#include "minecraft/mod/Resource.h"
#include "minecraft/mod/tasks/LocalTexturePackParseTask.h"

TexturePackFolderModel::TexturePackFolderModel(const QDir& dir,
                                               MinecraftInstance* instance,
                                               bool isIndexed,
                                               bool createDir,
                                               QObject* parent)
    : ResourceFolderModel(QDir(dir), instance, isIndexed, createDir, parent)
{
    m_columnNames = QStringList({ "Enable", "Name", "Last Modified", "Provider", "Size", "File Name", "Update" });
    m_columnNamesTranslated =
        QStringList({ "", tr("Name"), tr("Last Modified"), tr("Provider"), tr("Size"), tr("File Name"), tr("Update") });
    m_columnSortKeys = { SortType::Enabled, SortType::Name,     SortType::Date,      SortType::Provider,
                         SortType::Size,    SortType::Filename, SortType::LockUpdate };
    m_columnResizeModes = { QHeaderView::Fixed,       QHeaderView::Stretch,     QHeaderView::ResizeToContents, QHeaderView::Interactive,
                            QHeaderView::Interactive, QHeaderView::Interactive, QHeaderView::Interactive };
    m_columnsHideable = { false, false, true, true, true, true, true };
}

Task* TexturePackFolderModel::createParseTask(Resource& resource)
{
    return new LocalTexturePackParseTask(m_nextResolutionTicket, static_cast<TexturePack&>(resource));
}

QVariant TexturePackFolderModel::data(const QModelIndex& index, int role) const
{
    if (!validateIndex(index)) {
        return {};
    }

    int row = index.row();
    int column = index.column();

    switch (role) {
        case Qt::BackgroundRole:
            return rowBackground(row);
        case Qt::CheckStateRole:
            if (column == ActiveColumn) {
                return m_resources[row]->enabled() ? Qt::Checked : Qt::Unchecked;
            }
            return {};
        case Qt::UserRole:
            if (column == LockUpdateColumn) {
                return at(row).lockUpdate();
            }
            return {};
        default:
            break;
    }

    // map the columns to the base equivilents
    QModelIndex mappedIndex;
    switch (column) {
        case ActiveColumn:
            mappedIndex = index.siblingAtColumn(ResourceFolderModel::ActiveColumn);
            break;
        case NameColumn:
            mappedIndex = index.siblingAtColumn(ResourceFolderModel::NameColumn);
            break;
        case DateColumn:
            mappedIndex = index.siblingAtColumn(ResourceFolderModel::DateColumn);
            break;
        case ProviderColumn:
            mappedIndex = index.siblingAtColumn(ResourceFolderModel::ProviderColumn);
            break;
        case SizeColumn:
            mappedIndex = index.siblingAtColumn(ResourceFolderModel::SizeColumn);
            break;
        case FileNameColumn:
            mappedIndex = index.siblingAtColumn(ResourceFolderModel::FileNameColumn);
            break;
        default:
            break;
    }

    if (mappedIndex.isValid()) {
        return ResourceFolderModel::data(mappedIndex, role);
    }

    return {};
}

QList<MultiDecorationItemDelegate::Icon> TexturePackFolderModel::icons(int row) const
{
    auto result = ResourceFolderModel::icons(row);
    static const QSize s_iconSize = { 32, 32 };

    if (m_showImages) {
        QIcon icon;
        if (const auto pixmap = at(row).image(s_iconSize, Qt::KeepAspectRatio); !pixmap.isNull()) {
            icon = pixmap;
        } else {
            icon = QIcon::fromTheme("resourcepacks");
        }

        result.prepend({ .icon = icon, .size = s_iconSize });
    }

    return result;
}

QVariant TexturePackFolderModel::headerData(int section, [[maybe_unused]] Qt::Orientation orientation, int role) const
{
    switch (role) {
        case Qt::DisplayRole:
            switch (section) {
                case ActiveColumn:
                case NameColumn:
                case DateColumn:
                case ProviderColumn:
                case SizeColumn:
                case FileNameColumn:
                case LockUpdateColumn:
                    return columnNames().at(section);
                default:
                    return {};
            }
        case Qt::ToolTipRole: {
            switch (section) {
                case ActiveColumn:
                    return tr("Is the texture pack enabled?");
                case NameColumn:
                    return tr("The name of the texture pack.");
                case DateColumn:
                    return tr("The date and time this texture pack was last changed (or added).");
                case ProviderColumn:
                    return tr("The source provider of the texture pack.");
                case SizeColumn:
                    return tr("The size of the texture pack.");
                case FileNameColumn:
                    return tr("The file name of the texture pack.");
                case LockUpdateColumn:
                    return tr("Should this mod be updated?");
                default:
                    return {};
            }
        }
        default:
            break;
    }

    return {};
}

int TexturePackFolderModel::columnCount(const QModelIndex& parent) const
{
    return parent.isValid() ? 0 : NumColumns;
}
