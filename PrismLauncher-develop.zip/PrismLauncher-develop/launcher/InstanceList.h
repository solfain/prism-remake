// SPDX-License-Identifier: GPL-3.0-only
/*
 *  Prism Launcher - Minecraft Launcher
 *  Copyright (C) 2023 TheKodeToad <TheKodeToad@proton.me>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * This file incorporates work covered by the following copyright and
 * permission notice:
 *
 *      Copyright 2013-2021 MultiMC Contributors
 *
 *      Licensed under the Apache License, Version 2.0 (the "License");
 *      you may not use this file except in compliance with the License.
 *      You may obtain a copy of the License at
 *
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 *      Unless required by applicable law or agreed to in writing, software
 *      distributed under the License is distributed on an "AS IS" BASIS,
 *      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *      See the License for the specific language governing permissions and
 *      limitations under the License.
 */

#pragma once

#include <QAbstractListModel>
#include <QHash>
#include <QList>
#include <QObject>
#include <QPair>
#include <QSet>
#include <QStack>
#include <cstdint>

#include "minecraft/MinecraftInstance.h"

class QFileSystemWatcher;
class InstanceTask;

using InstanceId = QString;
using GroupId = QString;
using InstanceLocator = std::pair<MinecraftInstance*, int>;

struct TrashShortcutItem {
    ShortcutData data;
    QString trashPath;
};

struct TrashHistoryItem {
    QString id;
    QString path;
    QString trashPath;
    QString groupName;
    QList<TrashShortcutItem> shortcuts;
};

class InstanceList : public QAbstractListModel {
    Q_OBJECT

   public:
    explicit InstanceList(SettingsObject* settings, const QStringList& instDirs, QObject* parent = nullptr);
    ~InstanceList() override = default;

   public:
    QModelIndex index(int row, int column = 0, const QModelIndex& parent = QModelIndex()) const override;
    int rowCount(const QModelIndex& parent = QModelIndex()) const override;
    QVariant data(const QModelIndex& index, int role) const override;
    Qt::ItemFlags flags(const QModelIndex& index) const override;

    bool setData(const QModelIndex& index, const QVariant& value, int role) override;

    enum AdditionalRoles {
        GroupRole = Qt::UserRole,
        InstancePointerRole = 0x34B1CB48,  ///< Return pointer to real instance
        InstanceIDRole = 0x34B1CB49        ///< Return id if the instance
    };
    /*!
     * \brief Error codes returned by functions in the InstanceList class.
     * NoError Indicates that no error occurred.
     * UnknownError indicates that an unspecified error occurred.
     */
    enum InstListError : std::uint8_t { NoError = 0, UnknownError };

    MinecraftInstance* at(int i) const { return m_instances.at(i).get(); }

    int count() const { return static_cast<int>(m_instances.size()); }

    InstListError loadList();
    void saveNow();

    /* O(n) */
    MinecraftInstance* getInstanceById(const QString& id) const;
    int getInstIndex(MinecraftInstance* inst) const;
    /* O(n) */
    MinecraftInstance* getInstanceByManagedName(const QString& managedName) const;
    QModelIndex getInstanceIndexById(const QString& id) const;
    QStringList getGroups();
    bool isGroupCollapsed(const QString& groupName);

    GroupId getInstanceGroup(const InstanceId& id) const;
    void setInstanceGroup(const InstanceId& id, GroupId name);

    void deleteGroup(const GroupId& name);
    void renameGroup(const GroupId& src, const GroupId& dst);
    bool trashInstance(const InstanceId& id);
    bool trashedSomething() const;
    bool undoTrashInstance();
    void deleteInstance(const InstanceId& id);

    // Wrap an instance creation task in some more task machinery and make it ready to be used
    Task* wrapInstanceTask(InstanceTask* task);

    /**
     * Create a new empty staging area for instance creation and @return a path/key top commit it later.
     * Used by instance manipulation tasks.
     */
    QString getStagedInstancePath(const QString& targetDir);

    /**
     * Commit the staging area given by @keyPath to the provider - used when creation succeeds.
     * Used by instance manipulation tasks.
     * should_override is used when another similar instance already exists, and we want to override it
     * - for instance, when updating it.
     */
    bool commitStagedInstance(const QString& keyPath, const InstanceTask& instanceTask, QString groupName);

    Qt::DropActions supportedDragActions() const override;

    Qt::DropActions supportedDropActions() const override;

    bool canDropMimeData(const QMimeData* data, Qt::DropAction action, int row, int column, const QModelIndex& parent) const override;

    bool dropMimeData(const QMimeData* data, Qt::DropAction action, int row, int column, const QModelIndex& parent) override;

    QStringList mimeTypes() const override;
    QMimeData* mimeData(const QModelIndexList& indexes) const override;

    QStringList getLinkedInstancesById(const QString& id) const;

    QString primaryDir() const { return m_instDirs.isEmpty() ? QString() : m_instDirs.first(); }
    const QStringList& instanceDirs() const { return m_instDirs; }

   signals:
    void instancesChanged();
    void instanceSelectRequest(QString instanceId);
    void groupsChanged(QSet<QString> groups);

   public slots:
    void on_InstFolderChanged(const Setting& setting, const QVariant& value);
    void on_GroupStateChanged(const QString& group, bool collapsed);

   private slots:
    void propertiesChanged(MinecraftInstance* inst);
    void instanceDirContentsChanged(const QString& path);

   private:
    void migrateTotalPlayTime();
    void add(std::vector<std::unique_ptr<MinecraftInstance>>& list);
    void loadGroupList();
    void saveGroupList();
    QList<InstanceId> discoverInstances();
    std::unique_ptr<MinecraftInstance> loadInstance(const InstanceId& id);

    void increaseGroupCount(const QString& group);
    void decreaseGroupCount(const QString& group);

   private:
    std::vector<std::unique_ptr<MinecraftInstance>> m_instances;
    // id -> refs
    QMap<QString, int> m_groupNameCache;

    SettingsObject* m_globalSettings;
    QStringList m_instDirs;
    QHash<InstanceId, QString> m_instanceRootDirMap;
    QString rootDirOf(const InstanceId& id) const;
    QFileSystemWatcher* m_watcher;
    // FIXME: this is so inefficient that looking at it is almost painful.
    QSet<QString> m_collapsedGroups;
    QMap<InstanceId, GroupId> m_instanceGroupIndex;
    QSet<InstanceId> m_instanceSet;
    bool m_groupsLoaded = false;
    bool m_instancesProbed = false;

    QStack<TrashHistoryItem> m_trashHistory;
};
