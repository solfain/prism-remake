// SPDX-License-Identifier: GPL-3.0-only
/*
 *  Prism Launcher - Minecraft Launcher
 *  Copyright (c) 2025 Trial97 <alexandru.tripon97@gmail.com>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#pragma once

#include <QByteArray>
#include <QDateTime>
#include <QDir>
#include <QStringList>
#include <memory>
#include <optional>
#include <utility>

#include "Handle.h"
#include "Result.h"

struct archive;
struct archive_entry;

extern "C" {
int archive_read_free(archive*);
}

namespace MMCZip {
class ArchiveReader {
   public:
    explicit ArchiveReader(QString fileName) : m_archivePath(std::move(fileName)) {}
    virtual ~ArchiveReader() = default;

    QStringList getFiles();
    QString getZipName();
    Result<> collectFiles(bool onlyFiles = true);
    bool exists(const QString& filePath) const;

    class File {
       public:
        File();
        virtual ~File() = default;

        QString filename();
        bool isFile();
        QDateTime dateTime();
        const char* error();

        Result<QByteArray> readAll();
        Result<> skip();
        Result<> writeFile(archive* out, const QString& targetFileName = "", bool notBlock = false);
        Result<> writeFile(archive* out, const QString& targetFileName, std::optional<QDir> root, bool notBlock = false);

       private:
        int readNextHeader();

       private:
        friend ArchiveReader;
        Handle<struct archive, archive_read_free> m_archive;
        archive_entry* m_entry;
    };

    Result<std::unique_ptr<File>> goToFile(const QString& filename);
    Result<QByteArray> readFile(const QString& fileName);
    Result<> parse(const std::function<Result<>(File*)>&);
    Result<> parse(const std::function<Result<bool>(File*)>&);

   private:
    QString m_archivePath;
    size_t m_blockSize = 10240;

    QStringList m_fileNames;
};
}  // namespace MMCZip
