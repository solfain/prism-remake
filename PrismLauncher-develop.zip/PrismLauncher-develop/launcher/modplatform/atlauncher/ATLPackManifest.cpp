// SPDX-License-Identifier: GPL-3.0-only
/*
 *  Prism Launcher - Minecraft Launcher
 *  Copyright (c) 2022 Jamie Mansfield <jmansfield@cadixdev.org>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * This file incorporates work covered by the following copyright and
 * permission notice:
 *
 *      Copyright 2020-2021 Jamie Mansfield <jmansfield@cadixdev.org>
 *      Copyright 2021 Petr Mrazek <peterix@gmail.com>
 *
 *      Licensed under the Apache License, Version 2.0 (the "License");
 *      you may not use this file except in compliance with the License.
 *      You may obtain a copy of the License at
 *
 *          http://www.apache.org/licenses/LICENSE-2.0
 *
 *      Unless required by applicable law or agreed to in writing, software
 *      distributed under the License is distributed on an "AS IS" BASIS,
 *      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *      See the License for the specific language governing permissions and
 *      limitations under the License.
 */

#include "ATLPackManifest.h"
#include <expected>

#include "Json.h"
#include "modplatform/ModIndex.h"

static ATLauncher::DownloadType parseDownloadType(QString rawType)
{
    if (rawType == QString("server")) {
        return ATLauncher::DownloadType::Server;
    } else if (rawType == QString("browser")) {
        return ATLauncher::DownloadType::Browser;
    } else if (rawType == QString("direct")) {
        return ATLauncher::DownloadType::Direct;
    }

    return ATLauncher::DownloadType::Unknown;
}

static ATLauncher::ModType parseModType(QString rawType)
{
    // See https://wiki.atlauncher.com/mod_types
    if (rawType == QString("root")) {
        return ATLauncher::ModType::Root;
    } else if (rawType == QString("forge")) {
        return ATLauncher::ModType::Forge;
    } else if (rawType == QString("jar")) {
        return ATLauncher::ModType::Jar;
    } else if (rawType == QString("mods")) {
        return ATLauncher::ModType::Mods;
    } else if (rawType == QString("flan")) {
        return ATLauncher::ModType::Flan;
    } else if (rawType == QString("dependency") || rawType == QString("depandency")) {
        return ATLauncher::ModType::Dependency;
    } else if (rawType == QString("ic2lib")) {
        return ATLauncher::ModType::Ic2Lib;
    } else if (rawType == QString("denlib")) {
        return ATLauncher::ModType::DenLib;
    } else if (rawType == QString("coremods")) {
        return ATLauncher::ModType::Coremods;
    } else if (rawType == QString("mcpc")) {
        return ATLauncher::ModType::MCPC;
    } else if (rawType == QString("plugins")) {
        return ATLauncher::ModType::Plugins;
    } else if (rawType == QString("extract")) {
        return ATLauncher::ModType::Extract;
    } else if (rawType == QString("decomp")) {
        return ATLauncher::ModType::Decomp;
    } else if (rawType == QString("texturepack")) {
        return ATLauncher::ModType::TexturePack;
    } else if (rawType == QString("resourcepack")) {
        return ATLauncher::ModType::ResourcePack;
    } else if (rawType == QString("shaderpack")) {
        return ATLauncher::ModType::ShaderPack;
    } else if (rawType == QString("texturepackextract")) {
        return ATLauncher::ModType::TexturePackExtract;
    } else if (rawType == QString("resourcepackextract")) {
        return ATLauncher::ModType::ResourcePackExtract;
    } else if (rawType == QString("millenaire")) {
        return ATLauncher::ModType::Millenaire;
    }

    return ATLauncher::ModType::Unknown;
}

Result<> loadVersionLoader(ATLauncher::VersionLoader& p, const QJsonObject& obj)
{
    p.choose = obj["choose"].toBool();

    TRY_INTO(const auto& metadata, Json::requireObject(obj, "metadata"))
    p.latest = metadata.value("latest").toBool();
    p.recommended = metadata.value("recommended").toBool();

    TRY_INTO(const auto& loaderType, Json::requireString(obj, "type"))
    if (loaderType.isEmpty()) {  // no loader
        return {};
    }
    p.type = ModPlatform::getModLoaderFromString(loaderType);
    switch (p.type) {
        case ModPlatform::ModLoaderType::NeoForge:
        case ModPlatform::ModLoaderType::Forge: {
            p.version = metadata.value("version").toString("");
            break;
        }
        case ModPlatform::ModLoaderType::Fabric: {
            p.version = metadata.value("loader").toString("");
            break;
        }
        default: {
            return std::unexpected("unknown launcher: " + loaderType);
        }
    }
    return {};
}

Result<> loadVersionLibrary(ATLauncher::VersionLibrary& p, const QJsonObject& obj)
{
    TRY_INTO(p.url, Json::requireString(obj, "url"))
    TRY_INTO(p.file, Json::requireString(obj, "file"))
    TRY_INTO(p.md5, Json::requireString(obj, "md5"))

    TRY_INTO(p.download_raw, Json::requireString(obj, "download"))
    p.download = parseDownloadType(p.download_raw);

    p.server = obj["server"].toString("");
    return {};
}

Result<> loadVersionConfigs(ATLauncher::VersionConfigs& p, const QJsonObject& obj)
{
    TRY_INTO(p.filesize, Json::requireInteger(obj, "filesize"))
    TRY_INTO(p.sha1, Json::requireString(obj, "sha1"))
    return {};
}

Result<> loadVersionMod(ATLauncher::VersionMod& p, const QJsonObject& obj)
{
    TRY_INTO(p.name, Json::requireString(obj, "name"))
    TRY_INTO(p.version, Json::requireString(obj, "version"))
    TRY_INTO(p.url, Json::requireString(obj, "url"))
    TRY_INTO(p.file, Json::requireString(obj, "file"))
    p.md5 = obj["md5"].toString("");

    TRY_INTO(p.download_raw, Json::requireString(obj, "download"))
    p.download = parseDownloadType(p.download_raw);

    TRY_INTO(p.type_raw, Json::requireString(obj, "type"))
    p.type = parseModType(p.type_raw);

    // This contributes to the Minecraft Forge detection, where we rely on mod.type being "Forge"
    // when the mod represents Forge. As there is little difference between "Jar" and "Forge, some
    // packs regretfully use "Jar". This will correct the type to "Forge" in these cases (as best
    // it can).
    if (p.name == QString("Minecraft Forge") && p.type == ATLauncher::ModType::Jar) {
        p.type_raw = "forge";
        p.type = ATLauncher::ModType::Forge;
    }

    if (obj.contains("extractTo")) {
        TRY_INTO(p.extractTo_raw, Json::requireString(obj, "extractTo"))
        p.extractTo = parseModType(p.extractTo_raw);
        p.extractFolder = obj["extractFolder"].toString("").replace("%s%", "/");
    }

    if (obj.contains("decompType")) {
        TRY_INTO(p.decompType_raw, Json::requireString(obj, "decompType"))
        p.decompType = parseModType(p.decompType_raw);
        TRY_INTO(p.decompFile, Json::requireString(obj, "decompFile"))
    }

    p.description = obj["description"].toString("");
    p.optional = obj["optional"].toBool();
    p.recommended = obj["recommended"].toBool();
    p.selected = obj["selected"].toBool();
    p.hidden = obj["hidden"].toBool();
    p.library = obj["library"].toBool();
    p.group = obj["group"].toString("");
    if (obj.contains("depends")) {
        TRY_INTO(const auto& dependsArr, Json::requireArray(obj, "depends"))
        for (const auto depends : dependsArr) {
            TRY_INTO(const auto& v, Json::requireString(depends))
            p.depends.append(v);
        }
    }
    p.colour = obj["colour"].toString("");
    p.warning = obj["warning"].toString("");

    p.client = obj["client"].toBool();

    // computed
    p.effectively_hidden = p.hidden || p.library;
    return {};
}

static void loadVersionMessages(ATLauncher::VersionMessages& m, const QJsonObject& obj)
{
    m.install = obj["install"].toString("");
    m.update = obj["update"].toString("");
}

static void loadVersionMainClass(ATLauncher::PackVersionMainClass& m, const QJsonObject& obj)
{
    m.mainClass = obj["mainClass"].toString("");
    m.depends = obj["depends"].toString("");
}

static void loadVersionExtraArguments(ATLauncher::PackVersionExtraArguments& a, const QJsonObject& obj)
{
    a.arguments = obj["arguments"].toString("");
    a.depends = obj["depends"].toString("");
}

Result<> loadVersionKeep(ATLauncher::VersionKeep& k, const QJsonObject& obj)
{
    TRY_INTO(k.base, Json::requireString(obj, "base"))
    TRY_INTO(k.target, Json::requireString(obj, "target"))
    return {};
}

Result<> loadVersionKeeps(ATLauncher::VersionKeeps& k, const QJsonObject& obj)
{
    if (obj.contains("files")) {
        TRY_INTO(const auto& files, Json::requireArray(obj, "files"))
        for (const auto keepRaw : files) {
            ATLauncher::VersionKeep keep;
            TRY(Json::requireObject(keepRaw).and_then([&keep](const auto& v) { return loadVersionKeep(keep, v); }))
            k.files.append(keep);
        }
    }

    if (obj.contains("folders")) {
        TRY_INTO(const auto& folders, Json::requireArray(obj, "folders"))
        for (const auto keepRaw : folders) {
            ATLauncher::VersionKeep keep;
            TRY(Json::requireObject(keepRaw).and_then([&keep](const auto& v) { return loadVersionKeep(keep, v); }))
            k.folders.append(keep);
        }
    }
    return {};
}

Result<> loadVersionDelete(ATLauncher::VersionDelete& d, const QJsonObject& obj)
{
    TRY_INTO(d.base, Json::requireString(obj, "base"))
    TRY_INTO(d.target, Json::requireString(obj, "target"))
    return {};
}

Result<> loadVersionDeletes(ATLauncher::VersionDeletes& d, const QJsonObject& obj)
{
    if (obj.contains("files")) {
        TRY_INTO(const auto& files, Json::requireArray(obj, "files"))
        for (const auto deleteRaw : files) {
            ATLauncher::VersionDelete versionDelete;
            TRY(Json::requireObject(deleteRaw).and_then([&versionDelete](const auto& v) { return loadVersionDelete(versionDelete, v); }))
            d.files.append(versionDelete);
        }
    }

    if (obj.contains("folders")) {
        TRY_INTO(const auto& folders, Json::requireArray(obj, "folders"))
        for (const auto deleteRaw : folders) {
            ATLauncher::VersionDelete versionDelete;
            TRY(Json::requireObject(deleteRaw).and_then([&versionDelete](const auto& v) { return loadVersionDelete(versionDelete, v); }))
            d.folders.append(versionDelete);
        }
    }
    return {};
}

Result<> ATLauncher::loadVersion(PackVersion& v, const QJsonObject& obj)
{
    TRY_INTO(v.version, Json::requireString(obj, "version"))
    TRY_INTO(v.minecraft, Json::requireString(obj, "minecraft"))
    v.noConfigs = obj["noConfigs"].toBool();

    if (obj.contains("mainClass")) {
        TRY_INTO(const auto& main, Json::requireObject(obj, "mainClass"))
        loadVersionMainClass(v.mainClass, main);
    }

    if (obj.contains("extraArguments")) {
        TRY_INTO(const auto& arguments, Json::requireObject(obj, "extraArguments"))
        loadVersionExtraArguments(v.extraArguments, arguments);
    }

    if (obj.contains("loader")) {
        TRY(Json::requireObject(obj, "loader").and_then([&v](const auto& val) { return loadVersionLoader(v.loader, val); }))
    }

    if (obj.contains("libraries")) {
        TRY_INTO(const auto& libraries, Json::requireArray(obj, "libraries"))
        for (const auto libraryRaw : libraries) {
            ATLauncher::VersionLibrary target;
            TRY(Json::requireObject(libraryRaw).and_then([&target](const auto& v) { return loadVersionLibrary(target, v); }))
            v.libraries.append(target);
        }
    }

    if (obj.contains("mods")) {
        TRY_INTO(const auto& mods, Json::requireArray(obj, "mods"))
        for (const auto modRaw : mods) {
            ATLauncher::VersionMod mod;
            TRY(Json::requireObject(modRaw).and_then([&mod](const auto& v) { return loadVersionMod(mod, v); }))
            v.mods.append(mod);
        }
    }

    if (obj.contains("configs")) {
        TRY(Json::requireObject(obj, "configs").and_then([&v](const auto& val) { return loadVersionConfigs(v.configs, val); }))
    }

    auto colourObj = obj["colours"].toObject();
    for (const auto& key : colourObj.keys()) {
        TRY_INTO(v.colours[key], Json::requireString(colourObj.value(key), "colour"))
    }

    auto warningsObj = obj["warnings"].toObject();
    for (const auto& key : warningsObj.keys()) {
        TRY_INTO(v.warnings[key], Json::requireString(warningsObj.value(key), "warning"))
    }

    auto messages = obj["messages"].toObject();
    loadVersionMessages(v.messages, messages);

    auto keeps = obj["keeps"].toObject();
    TRY(loadVersionKeeps(v.keeps, keeps))

    auto deletes = obj["deletes"].toObject();
    TRY(loadVersionDeletes(v.deletes, deletes))
    return {};
}
